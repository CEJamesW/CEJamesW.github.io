import { buildChatCompletionsRequest } from "../background/llm-client.js";
import { DEFAULT_SETTINGS } from "../shared/default-settings.js";

const form = document.querySelector("#settings-form");
const statusEl = document.querySelector("#status");
const testButton = document.querySelector("#test-connection");

restoreSettings();

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  await chrome.storage.local.set(readForm());
  setStatus("配置已保存", "ok");
});

testButton.addEventListener("click", async () => {
  testButton.disabled = true;
  setStatus("正在测试连接...", "idle");

  try {
    const config = readForm();
    const request = buildChatCompletionsRequest(config, {
      title: "Connection test",
      url: "chrome-extension://options",
      html: "<html><body>Hello</body></html>"
    });
    const body = JSON.parse(request.options.body);
    body.messages[1].content = "请只回复：连接成功";

    const response = await fetch(request.url, {
      ...request.options,
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      const text = await response.text();
      throw new Error(`HTTP ${response.status}: ${text.slice(0, 240)}`);
    }

    setStatus("连接测试成功", "ok");
  } catch (error) {
    setStatus(error?.message || "连接测试失败", "error");
  } finally {
    testButton.disabled = false;
  }
});

async function restoreSettings() {
  const settings = await chrome.storage.local.get(DEFAULT_SETTINGS);
  for (const [key, value] of Object.entries(settings)) {
    const field = form.elements[key];
    if (field) {
      field.value = value;
    }
  }
}

function readForm() {
  return {
    apiBaseUrl: form.elements.apiBaseUrl.value.trim().replace(/\/+$/, ""),
    apiKey: form.elements.apiKey.value.trim(),
    model: form.elements.model.value.trim(),
    targetLanguage: form.elements.targetLanguage.value.trim() || DEFAULT_SETTINGS.targetLanguage,
    requestTimeoutMs: Number(form.elements.requestTimeoutMs.value) || DEFAULT_SETTINGS.requestTimeoutMs
  };
}

function setStatus(message, kind) {
  statusEl.textContent = message;
  statusEl.dataset.kind = kind;
}
