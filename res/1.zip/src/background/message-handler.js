import { normalizeConfig } from "./llm-client.js";

export function createMessageHandler({ loadConfig, translateDomHtml, openOptionsPage }) {
  return async function handleMessage(message) {
    if (message?.type === "OPEN_OPTIONS") {
      await openOptionsPage();
      return { ok: true };
    }

    if (message?.type !== "TRANSLATE_DOM_HTML") {
      return undefined;
    }

    let config;
    try {
      config = normalizeConfig(await loadConfig());
    } catch (error) {
      if (error.code === "CONFIG_REQUIRED") {
        return {
          ok: false,
          code: "CONFIG_REQUIRED",
          message: "Open the extension settings and configure Base URL, API key, and model first."
        };
      }
      throw error;
    }

    return translateDomHtml(config, message.payload || {});
  };
}
