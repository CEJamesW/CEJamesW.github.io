const DEFAULT_TARGET_LANGUAGE = "简体中文";
const DEFAULT_TIMEOUT_MS = 120000;
const DEFAULT_MAX_DIRECT_CHARS = 120000;
const DEFAULT_CHUNK_CHARS = 90000;

export function normalizeConfig(config = {}) {
  const normalized = {
    apiBaseUrl: String(config.apiBaseUrl ?? "").trim().replace(/\/+$/, ""),
    apiKey: String(config.apiKey ?? "").trim(),
    model: String(config.model ?? "").trim(),
    targetLanguage: String(config.targetLanguage ?? DEFAULT_TARGET_LANGUAGE).trim() || DEFAULT_TARGET_LANGUAGE,
    requestTimeoutMs: Number(config.requestTimeoutMs ?? DEFAULT_TIMEOUT_MS) || DEFAULT_TIMEOUT_MS
  };

  if (!normalized.apiBaseUrl || !normalized.apiKey || !normalized.model) {
    const error = new Error("CONFIG_REQUIRED");
    error.code = "CONFIG_REQUIRED";
    throw error;
  }

  return normalized;
}

export function buildChatCompletionsRequest(config, payload, options = {}) {
  const normalized = normalizeConfig(config);
  const body = {
    model: normalized.model,
    temperature: 0.2,
    messages: options.messages || buildFinalAnswerMessages(normalized, payload)
  };

  return {
    url: `${normalized.apiBaseUrl}/chat/completions`,
    options: {
      method: "POST",
      headers: {
        Authorization: `Bearer ${normalized.apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(body)
    },
    timeoutMs: normalized.requestTimeoutMs
  };
}

export function splitPageContext(context, chunkChars = DEFAULT_CHUNK_CHARS) {
  const normalized = normalizePageContext(context);
  if (!normalized) {
    return [""];
  }

  const paragraphs = normalized.split(/\n+/);
  const chunks = [];
  let current = "";

  for (const paragraph of paragraphs) {
    if (!paragraph) {
      continue;
    }

    if (paragraph.length > chunkChars) {
      if (current) {
        chunks.push(current);
        current = "";
      }
      for (let index = 0; index < paragraph.length; index += chunkChars) {
        chunks.push(paragraph.slice(index, index + chunkChars));
      }
      continue;
    }

    const candidate = current ? `${current}\n\n${paragraph}` : paragraph;
    if (candidate.length > chunkChars && current) {
      chunks.push(current);
      current = paragraph;
    } else {
      current = candidate;
    }
  }

  if (current) {
    chunks.push(current);
  }

  return chunks.length ? chunks : [normalized.slice(0, chunkChars)];
}

export async function parseChatCompletionsResponse(response) {
  if (!response.ok) {
    const text = await safeReadText(response);
    throw createClientError("API_ERROR", `Model API returned HTTP ${response.status}: ${text}`);
  }

  const data = await response.json();
  const translation = data?.choices?.[0]?.message?.content;
  if (typeof translation !== "string" || !translation.trim()) {
    throw createClientError("INVALID_RESPONSE", "Model API response did not contain translated text.");
  }

  return translation.trim();
}

export async function translateDomHtml(config, payload, options = {}) {
  try {
    const normalized = normalizeConfig(config);
    const fetcher = options.fetcher ?? fetch;
    const pageContext = normalizePageContext(payload.html || payload.text || "");
    const maxDirectChars = options.maxDirectChars || DEFAULT_MAX_DIRECT_CHARS;

    if (pageContext.length <= maxDirectChars) {
      return await requestFinalAnswer(normalized, { ...payload, html: pageContext }, { fetcher });
    }

    const chunks = splitPageContext(pageContext, options.chunkChars || DEFAULT_CHUNK_CHARS);
    const summaries = [];

    for (let index = 0; index < chunks.length; index += 1) {
      const messages = buildChunkExtractionMessages(normalized, {
        ...payload,
        chunk: chunks[index],
        chunkIndex: index + 1,
        chunkCount: chunks.length
      });
      summaries.push(await requestText(normalized, messages, { fetcher }));
    }

    return await requestFinalAnswer(
      normalized,
      {
        ...payload,
        html: [
          `以下是超长页面按顺序分块提取出的题目相关原文信息，共 ${chunks.length} 段。`,
          "请基于这些信息完成题目；如果信息仍不足，请明确指出缺失项。",
          "",
          summaries.map((summary, index) => `【第 ${index + 1} 段提取】\n${summary}`).join("\n\n")
        ].join("\n")
      },
      { fetcher }
    );
  } catch (error) {
    const code = error.code || "NETWORK_ERROR";
    return {
      ok: false,
      code,
      message: error.message || "Network request failed."
    };
  }
}

function buildFinalAnswerMessages(config, payload) {
  return [
    {
      role: "system",
      content:
        "你是题目解答助手。用户会给你从网页中按可见顺序提取的题目上下文。必须保留题干、材料、选项、表格、数字、公式、限制条件之间的关系来作答。不要输出 HTML 或 Markdown。"
    },
    {
      role: "user",
      content: [
        `回答语言：${config.targetLanguage}`,
        `页面标题：${payload.title || ""}`,
        `页面地址：${payload.url || ""}`,
        "完成题目。请根据下面页面可见文本中的题目、材料、选项、表格、输入框内容和限制条件作答。不要返回 HTML 源码和 Markdown 格式的文本，仅返回所做的题目和答案：",
        normalizePageContext(payload.html || payload.text || "")
      ].join("\n\n")
    }
  ];
}

function buildChunkExtractionMessages(config, payload) {
  return [
    {
      role: "system",
      content:
        "你是超长题目上下文的信息保真提取器。不要作答。只从当前分段中提取与题目有关的原文信息，保留题干、材料、选项、表格、数字、公式、单位、限制条件、输入框内容和上下文指代。删除导航、广告、重复按钮等无关内容。不要编造。"
    },
    {
      role: "user",
      content: [
        `回答语言：${config.targetLanguage}`,
        `页面标题：${payload.title || ""}`,
        `页面地址：${payload.url || ""}`,
        `这是超长页面的第 ${payload.chunkIndex}/${payload.chunkCount} 段。`,
        "请提取本段中所有与完成题目相关的信息。不要解题，只输出保留下来的原文要点：",
        payload.chunk || ""
      ].join("\n\n")
    }
  ];
}

async function requestFinalAnswer(config, payload, options) {
  const translation = await requestText(config, buildFinalAnswerMessages(config, payload), options);
  return { ok: true, translation };
}

async function requestText(config, messages, options = {}) {
  const fetcher = options.fetcher ?? fetch;
  const { url, options: requestOptions, timeoutMs } = buildChatCompletionsRequest(config, {}, { messages });
  const response = await fetchWithTimeout(fetcher, url, requestOptions, timeoutMs);
  return parseChatCompletionsResponse(response);
}

function normalizePageContext(value) {
  return stripHtml(String(value || ""))
    .replace(/\r/g, "\n")
    .replace(/[ \t\f\v]+/g, " ")
    .replace(/ *\n+ */g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function stripHtml(value) {
  return value
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, "\n")
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, "\n")
    .replace(/<noscript\b[^>]*>[\s\S]*?<\/noscript>/gi, "\n")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/(p|div|section|article|li|tr|td|th|h[1-6]|table|ul|ol|main|header|footer|form)>/gi, "\n")
    .replace(/<[^>]+>/g, " ");
}

async function fetchWithTimeout(fetcher, url, requestOptions, timeoutMs) {
  if (typeof AbortController === "undefined") {
    return fetcher(url, requestOptions);
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetcher(url, {
      ...requestOptions,
      signal: controller.signal
    });
  } catch (error) {
    if (error?.name === "AbortError") {
      throw createClientError("NETWORK_ERROR", "Model request timed out.");
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function safeReadText(response) {
  try {
    const text = await response.text();
    return text.slice(0, 500) || "No response body";
  } catch {
    return "Unable to read response body";
  }
}

function createClientError(code, message) {
  const error = new Error(message);
  error.code = code;
  return error;
}
