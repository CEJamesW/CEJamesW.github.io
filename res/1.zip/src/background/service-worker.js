import { translateDomHtml } from "./llm-client.js";
import { createMessageHandler } from "./message-handler.js";
import { DEFAULT_SETTINGS } from "../shared/default-settings.js";

async function loadConfig() {
  return chrome.storage.local.get(DEFAULT_SETTINGS);
}

const handleMessage = createMessageHandler({
  loadConfig,
  translateDomHtml,
  openOptionsPage: () => chrome.runtime.openOptionsPage()
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message)
    .then((response) => {
      if (response !== undefined) {
        sendResponse(response);
      }
    })
    .catch((error) => {
      sendResponse({
        ok: false,
        code: "UNEXPECTED_ERROR",
        message: error?.message || "Unexpected extension error."
      });
    });

  return true;
});
