export const DEFAULT_SETTINGS = Object.freeze({
  apiBaseUrl: "https://ai.saurlax.com/v1",
  apiKey: "sk-hXR8WlPH3OyxLSJntpSNvZAfItRvSqt2xj0AEFDdfKSKJm76",
  model: "kimi-k2.6",
  targetLanguage: "简体中文",
  requestTimeoutMs: 120000
});
