const HOST_ID = "chrome-dom-translator-root";
const TOP_LAYER_Z_INDEX = 2147483647;
const PANEL_WIDTH = 360;
const DEFAULT_MAX_CONTEXT_CHARS = 180000;
const SKIPPED_TAGS = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE", "SVG", "CANVAS"]);
const BLOCK_TAGS = new Set([
  "ADDRESS",
  "ARTICLE",
  "ASIDE",
  "BLOCKQUOTE",
  "BR",
  "DD",
  "DIV",
  "DL",
  "DT",
  "FIELDSET",
  "FIGCAPTION",
  "FIGURE",
  "FOOTER",
  "FORM",
  "H1",
  "H2",
  "H3",
  "H4",
  "H5",
  "H6",
  "HEADER",
  "HR",
  "LI",
  "MAIN",
  "NAV",
  "OL",
  "P",
  "PRE",
  "SECTION",
  "TABLE",
  "TBODY",
  "TD",
  "TFOOT",
  "TH",
  "THEAD",
  "TR",
  "UL"
]);

if (!document.getElementById(HOST_ID)) {
  injectPanel();
}

function injectPanel() {
  const host = document.createElement("div");
  host.id = HOST_ID;
  setHostStyle(host);
  document.documentElement.append(host);

  const shadow = host.attachShadow({ mode: "open" });
  shadow.append(createStyle(), createPanel());

  const panel = shadow.querySelector(".panel");
  const translateButton = shadow.querySelector("[data-action='translate']");
  const output = shadow.querySelector(".output");

  const extractDomHtml = createDomSourceExtractor(document, HOST_ID);

  translateButton.addEventListener("click", async () => {
    setBusy(true);
    output.value = "...";

    try {
      const response = await chrome.runtime.sendMessage({
        type: "TRANSLATE_DOM_HTML",
        payload: {
          html: extractDomHtml(),
          url: location.href,
          title: document.title
        }
      });

      if (response?.ok) {
        output.value = response.translation;
      } else {
        output.value = `${errorTitle(response?.code)}：${response?.message || "失败。"}`;
      }
    } catch (error) {
      output.value = `请求失败：${error?.message || "无法连接扩展后台。"}`;
    } finally {
      setBusy(false);
    }
  });

  enableDrag(panel);
  keepHostLast(host);

  function setBusy(isBusy) {
    translateButton.disabled = isBusy;
    translateButton.textContent = isBusy ? "稍等" : "开整";
  }
}

function createDomSourceExtractor(documentRef, hostId, options = {}) {
  return function extractPageContext() {
    const root = documentRef.body || documentRef.documentElement;
    const chunks = [];
    appendVisibleText(root, {
      chunks,
      hostId,
      getComputedStyle: options.getComputedStyle || globalThis.getComputedStyle
    });

    return trimPageContext(normalizeContext(chunks.join("")), options.maxChars || DEFAULT_MAX_CONTEXT_CHARS);
  };
}

function trimPageContext(context, maxChars = DEFAULT_MAX_CONTEXT_CHARS) {
  if (context.length <= maxChars) {
    return context;
  }

  return [
    context.slice(0, maxChars),
    "",
    `[内容过长，已在 ${maxChars} 字符处截断。若题目材料缺失，请缩小页面范围或分批处理。]`
  ].join("\n");
}

function appendVisibleText(node, state) {
  if (!node) {
    return;
  }

  if (node.nodeType === 3) {
    state.chunks.push(node.nodeValue || "");
    return;
  }

  if (node.nodeType !== 1) {
    return;
  }

  const tagName = node.tagName || "";
  if (node.id === state.hostId || SKIPPED_TAGS.has(tagName) || isHidden(node, state.getComputedStyle)) {
    return;
  }

  if (BLOCK_TAGS.has(tagName)) {
    state.chunks.push("\n");
  }

  appendFormValue(node, state.chunks);

  for (const child of Array.from(node.childNodes || [])) {
    appendVisibleText(child, state);
  }

  if (BLOCK_TAGS.has(tagName)) {
    state.chunks.push("\n");
  }
}

function appendFormValue(node, chunks) {
  const tagName = node.tagName || "";
  if (tagName === "INPUT") {
    const type = String(node.type || "").toLowerCase();
    if (type === "hidden" || type === "password" || type === "file") {
      return;
    }
    if ((type === "checkbox" || type === "radio") && node.checked) {
      chunks.push(` [已选：${node.value || node.getAttribute?.("aria-label") || "选项"}] `);
      return;
    }
    if (node.value) {
      chunks.push(` ${node.value} `);
    } else if (node.placeholder) {
      chunks.push(` ${node.placeholder} `);
    }
    return;
  }

  if (tagName === "TEXTAREA" && node.value) {
    chunks.push(` ${node.value} `);
    return;
  }

  if (tagName === "SELECT") {
    for (const option of Array.from(node.options || [])) {
      chunks.push(` ${option.selected ? "[已选]" : "[选项]"}${option.text || option.value || ""} `);
    }
  }
}

function isHidden(node, getComputedStyleRef) {
  if (node.hidden || node.getAttribute?.("aria-hidden") === "true") {
    return true;
  }

  const style = node.getAttribute?.("style") || "";
  if (/display\s*:\s*none/i.test(style) || /visibility\s*:\s*hidden/i.test(style)) {
    return true;
  }

  if (typeof getComputedStyleRef === "function") {
    const computed = getComputedStyleRef(node);
    if (computed?.display === "none" || computed?.visibility === "hidden" || computed?.opacity === "0") {
      return true;
    }
  }

  return false;
}

function normalizeContext(raw) {
  return raw
    .replace(/\r/g, "\n")
    .replace(/[ \t\f\v]+/g, " ")
    .replace(/ *\n+ */g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function setHostStyle(host) {
  host.style.setProperty("all", "initial", "important");
  host.style.setProperty("position", "fixed", "important");
  host.style.setProperty("inset", "0 auto auto 0", "important");
  host.style.setProperty("width", "0", "important");
  host.style.setProperty("height", "0", "important");
  host.style.setProperty("z-index", String(TOP_LAYER_Z_INDEX), "important");
  host.style.setProperty("pointer-events", "none", "important");
}

function keepHostLast(host) {
  let scheduled = false;
  const moveLast = () => {
    scheduled = false;
    setHostStyle(host);
    if (host.parentNode === document.documentElement && document.documentElement.lastElementChild !== host) {
      document.documentElement.append(host);
    }
  };

  const scheduleMoveLast = () => {
    if (scheduled) {
      return;
    }
    scheduled = true;
    requestAnimationFrame(moveLast);
  };

  new MutationObserver(scheduleMoveLast).observe(document.documentElement, {
    childList: true
  });
}

function createPanel() {
  const wrapper = document.createElement("section");
  wrapper.className = "panel";
  wrapper.setAttribute("aria-label", "DOM Translator floating panel");
  wrapper.innerHTML = `
    <button type="button" class="primary" data-action="translate">开整</button>
    <textarea class="output" readonly aria-live="polite" placeholder=""></textarea>
  `;
  return wrapper;
}

function createStyle() {
  const style = document.createElement("style");
  style.textContent = `
    :host {
      color-scheme: light;
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      position: fixed;
      z-index: ${TOP_LAYER_Z_INDEX};
    }

    * {
      box-sizing: border-box;
      letter-spacing: 0;
    }

    .panel {
      display: grid;
      gap: 10px;
      position: fixed;
      z-index: ${TOP_LAYER_Z_INDEX};
      top: 18px;
      right: 18px;
      width: min(${PANEL_WIDTH}px, calc(100vw - 24px));
      max-height: min(560px, calc(100vh - 24px));
      background: #f8fafc;
      color: #172033;
      border: 1px solid #9fb3c8;
      border-radius: 8px;
      box-shadow: 0 18px 44px rgba(15, 23, 42, 0.22);
      cursor: move;
      overflow: hidden;
      padding: 12px;
      user-select: none;
      pointer-events: auto;
    }

    button {
      align-items: center;
      background: #ffffff;
      border: 1px solid #b8c7d6;
      border-radius: 6px;
      color: #172033;
      cursor: pointer;
      display: inline-flex;
      font: inherit;
      font-size: 12px;
      font-weight: 650;
      height: 30px;
      justify-content: center;
      min-width: 34px;
      padding: 0 10px;
      white-space: nowrap;
    }

    button:hover {
      background: #e9f2fb;
    }

    button:focus-visible {
      outline: 2px solid #f2b84b;
      outline-offset: 2px;
    }

    button:disabled {
      cursor: wait;
      opacity: 0.72;
    }

    .primary {
      background: #f8fafc;
      border-color: #cbd5e1;
      color: #334155;
      cursor: pointer;
      justify-self: start;
      min-width: 96px;
    }

    .primary:hover {
      background: #f1f5f9;
      border-color: #94a3b8;
    }

    .primary:active {
      background: #e2e8f0;
    }

    .output {
      background: #ffffff;
      border: 1px solid #d6e0ea;
      border-radius: 6px;
      color: #172033;
      cursor: move;
      font-family: "Segoe UI", ui-sans-serif, system-ui, sans-serif;
      font-size: 13px;
      line-height: 1.55;
      margin: 0;
      min-width: 0;
      outline: none;
      max-height: 360px;
      min-height: 148px;
      overflow: auto;
      padding: 10px;
      resize: vertical;
      white-space: pre-wrap;
      width: 100%;
      word-break: break-word;
    }
  `;
  return style;
}

function enableDrag(panel) {
  let startX = 0;
  let startY = 0;
  let startLeft = 0;
  let startTop = 0;

  panel.addEventListener("pointerdown", (event) => {
    if (event.button !== 0) {
      return;
    }
    if (event.target.closest("button")) {
      return;
    }

    const rect = panel.getBoundingClientRect();
    startX = event.clientX;
    startY = event.clientY;
    startLeft = rect.left;
    startTop = rect.top;

    panel.style.left = `${rect.left}px`;
    panel.style.top = `${rect.top}px`;
    panel.style.right = "auto";
    panel.setPointerCapture(event.pointerId);
  });

  panel.addEventListener("pointermove", (event) => {
    if (!panel.hasPointerCapture(event.pointerId)) {
      return;
    }

    const nextLeft = clamp(startLeft + event.clientX - startX, 8, window.innerWidth - 48);
    const nextTop = clamp(startTop + event.clientY - startY, 8, window.innerHeight - 48);
    panel.style.left = `${nextLeft}px`;
    panel.style.top = `${nextTop}px`;
  });

  panel.addEventListener("pointerup", (event) => {
    if (panel.hasPointerCapture(event.pointerId)) {
      panel.releasePointerCapture(event.pointerId);
    }
  });
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(value, max));
}

function errorTitle(code) {
  if (code === "CONFIG_REQUIRED") {
    return "需要先配置模型";
  }
  if (code === "API_ERROR") {
    return "模型接口返回错误";
  }
  if (code === "INVALID_RESPONSE") {
    return "模型响应格式异常";
  }
  return "失败";
}
