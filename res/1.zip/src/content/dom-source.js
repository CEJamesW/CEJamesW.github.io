const DEFAULT_MAX_CONTEXT_CHARS = 180000;
const SKIPPED_TAGS = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE", "SVG", "CANVAS"]);
const BLOCK_TAGS = new Set([
  "ADDRESS",
  "ARTICLE",
  "ASIDE",
  "BLOCKQUOTE",
  "BR",
  "DD",
  "DIV",
  "DL",
  "DT",
  "FIELDSET",
  "FIGCAPTION",
  "FIGURE",
  "FOOTER",
  "FORM",
  "H1",
  "H2",
  "H3",
  "H4",
  "H5",
  "H6",
  "HEADER",
  "HR",
  "LI",
  "MAIN",
  "NAV",
  "OL",
  "P",
  "PRE",
  "SECTION",
  "TABLE",
  "TBODY",
  "TD",
  "TFOOT",
  "TH",
  "THEAD",
  "TR",
  "UL"
]);

export function createDomSourceExtractor(documentRef, hostId, options = {}) {
  return createPageContextExtractor(documentRef, hostId, options);
}

export function createPageContextExtractor(documentRef, hostId, options = {}) {
  return function extractPageContext() {
    const root = documentRef.body || documentRef.documentElement;
    const chunks = [];
    appendVisibleText(root, {
      chunks,
      hostId,
      getComputedStyle: options.getComputedStyle || globalThis.getComputedStyle,
      preserveWhitespaceTags: new Set(["PRE", "TEXTAREA"])
    });

    return trimPageContext(normalizeContext(chunks.join("")), options.maxChars || DEFAULT_MAX_CONTEXT_CHARS);
  };
}

export function trimPageContext(context, maxChars = DEFAULT_MAX_CONTEXT_CHARS) {
  if (context.length <= maxChars) {
    return context;
  }

  return [
    context.slice(0, maxChars),
    "",
    `[内容过长，已在 ${maxChars} 字符处截断。若题目材料缺失，请缩小页面范围或分批处理。]`
  ].join("\n");
}

function appendVisibleText(node, state) {
  if (!node) {
    return;
  }

  if (node.nodeType === 3) {
    state.chunks.push(node.nodeValue || "");
    return;
  }

  if (node.nodeType !== 1) {
    return;
  }

  const tagName = node.tagName || "";
  if (node.id === state.hostId || SKIPPED_TAGS.has(tagName) || isHidden(node, state.getComputedStyle)) {
    return;
  }

  if (BLOCK_TAGS.has(tagName)) {
    state.chunks.push("\n");
  }

  appendFormValue(node, state.chunks);

  for (const child of Array.from(node.childNodes || [])) {
    appendVisibleText(child, state);
  }

  if (BLOCK_TAGS.has(tagName)) {
    state.chunks.push("\n");
  }
}

function appendFormValue(node, chunks) {
  const tagName = node.tagName || "";
  if (tagName === "INPUT") {
    const type = String(node.type || "").toLowerCase();
    if (type === "hidden" || type === "password" || type === "file") {
      return;
    }
    if ((type === "checkbox" || type === "radio") && node.checked) {
      chunks.push(` [已选：${node.value || node.getAttribute?.("aria-label") || "选项"}] `);
      return;
    }
    if (node.value) {
      chunks.push(` ${node.value} `);
    } else if (node.placeholder) {
      chunks.push(` ${node.placeholder} `);
    }
    return;
  }

  if (tagName === "TEXTAREA" && node.value) {
    chunks.push(` ${node.value} `);
    return;
  }

  if (tagName === "SELECT") {
    for (const option of Array.from(node.options || [])) {
      chunks.push(` ${option.selected ? "[已选]" : "[选项]"}${option.text || option.value || ""} `);
    }
  }
}

function isHidden(node, getComputedStyleRef) {
  if (node.hidden || node.getAttribute?.("aria-hidden") === "true") {
    return true;
  }

  const style = node.getAttribute?.("style") || "";
  if (/display\s*:\s*none/i.test(style) || /visibility\s*:\s*hidden/i.test(style)) {
    return true;
  }

  if (typeof getComputedStyleRef === "function") {
    const computed = getComputedStyleRef(node);
    if (computed?.display === "none" || computed?.visibility === "hidden" || computed?.opacity === "0") {
      return true;
    }
  }

  return false;
}

function normalizeContext(raw) {
  return raw
    .replace(/\r/g, "\n")
    .replace(/[ \t\f\v]+/g, " ")
    .replace(/ *\n+ */g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}
